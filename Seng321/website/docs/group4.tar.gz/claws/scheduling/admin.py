from scheduling.models import Shift
from django.contrib import admin

admin.site.register(Shift)
