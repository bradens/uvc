from appointments.models import Appointment, KennellingAppointment
from django.contrib import admin

admin.site.register(Appointment)
admin.site.register(KennellingAppointment)
